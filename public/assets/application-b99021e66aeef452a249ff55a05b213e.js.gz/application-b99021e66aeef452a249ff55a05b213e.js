// ...
//= require jquery
//= require jquery_ujs
//= require_tree .
$(document).ready(function(){alert("hello world")});