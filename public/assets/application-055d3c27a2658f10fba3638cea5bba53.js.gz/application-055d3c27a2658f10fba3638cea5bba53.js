//
//= require_self
//= require jquery-ui
$(document).ready(function(){alert("hello world")});